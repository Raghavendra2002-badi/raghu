from tkinter import *
from tkinter import messagebox

def open_account(parent):
    approve_win = Toplevel(parent)
    approve_win.title("Open Account")
    
    approve_win.geometry("300x400")