from tkinter import *
from tkinter import messagebox

def withdraw(parent):
    withdraw=Toplevel(parent)
    withdraw.title('Withdraw')
    withdraw.geometry("400x300")