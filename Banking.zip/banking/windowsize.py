import tkinter as tk

def screen_size(root):
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    window_width = int(screen_width * 0.9)
    window_height = int(screen_height * 0.8)
    position_right = int(screen_width * 0.05)
    position_down = int(screen_height * 0.05)
    
    root.geometry(f"{window_width}x{window_height}+{position_right}+{position_down}")