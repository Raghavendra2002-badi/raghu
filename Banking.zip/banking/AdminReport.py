from tkinter import *
from tkinter import messagebox

def report(parent):
    report = Toplevel(parent)
    report.title("Report")
    
    report.geometry("400x300")