from tkinter import *
from tkinter import messagebox

def amt_transfer(parent):
    amounttransfer=Toplevel(parent)
    amounttransfer.title('Amount Transfer')
    amounttransfer.geometry("400x300")