from tkinter import *
from tkinter import messagebox

def approve(parent):
    approve_win = Toplevel(parent)
    approve_win.title("Approve Account")
    
    approve_win.geometry("400x300")