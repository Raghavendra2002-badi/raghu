from tkinter import *
from tkinter import messagebox
import subprocess
from windowsize import screen_size

class user_window:

    def __init__(self, parent):
        self.parent=parent
        self.userdashboard()
        self.parent.title("Welcome User")
        p1 = PhotoImage(file='./images/bank1.png')
        self.parent.iconphoto(True, p1)
        self.parent.configure(background="#023047")
        
    def userdashboard(self):
        user_win = Toplevel(self.parent)

        def exit_app():
            user_win.destroy()
            self.parent.destroy()
            subprocess.run(["python", "login.py"])  # Reopen login window
            
        menu_bar=Menu(user_win)

        account_menu=Menu(menu_bar, tearoff=0)
        account_menu.add_command(label="Exit",command=exit_app)
        menu_bar.add_cascade(label="Account Management", menu=account_menu)

        transation_menu=Menu(menu_bar, tearoff=0)
        transation_menu.add_command(label="Withdraw")
        transation_menu.add_separator()
        transation_menu.add_command(label="Amount Transfer")
        transation_menu.add_separator()
        transation_menu.add_command(label="Balance")
        menu_bar.add_cascade(label="Transation",menu=transation_menu)

        user_win.config(menu=menu_bar)
        screen_size(user_win)

        # Bind the close event of the admin window to reopen the login page
        user_win.protocol("WM_DELETE_WINDOW", lambda: exit_app())