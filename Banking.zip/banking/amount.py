from tkinter import *
from tkinter import messagebox

def account_info(parent):
    acc=Toplevel(parent)
    acc.title('Amount')
    acc.geometry("400x300")