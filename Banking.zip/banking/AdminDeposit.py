from tkinter import *
from tkinter import messagebox

def adm_deposit(parent):
    admindeposit=Toplevel(parent)
    admindeposit.title('Deposit')
    admindeposit.geometry("400x300")