from tkinter import *
from tkinter import messagebox
import mysql.connector
import subprocess
from datetime import datetime

class newaccountreg:
    def __init__(self, parent):
        self.register=parent
        self.register.geometry("411x403+437+152")
        self.register.minsize(120, 1)
        self.register.maxsize(1370, 749)
        self.register.resizable(0, 0)
        self.register.title("Create account")
        self.register.configure(background="#f2f3f4")
        self.register.configure(highlightbackground="#d9d9d9")
        self.register.configure(highlightcolor="black")

        # Full Name
        Label(self.register, text="Full Name:", background="#f2f3f4").place(relx=0.316, rely=0.025, height=26, width=75)
        self.Entry1 = Entry(self.register, background="#cae4ff")
        self.Entry1.place(relx=0.511, rely=0.027, height=20, relwidth=0.302)
        self.Entry1.focus_set()

        # Username
        Label(self.register, text="User Name:", background="#f2f3f4").place(relx=0.316, rely=0.099, height=27, width=75)
        self.Entry2 = Entry(self.register, background="#cae4ff")
        self.Entry2.place(relx=0.511, rely=0.099, height=20, relwidth=0.302)

        # Account Type
        Label(self.register, text="Account Type:", background="#f2f3f4").place(relx=0.287, rely=0.169, height=26, width=83)
        self.acc_type = StringVar(value="")
        Radiobutton(self.register, text="Savings", variable=self.acc_type, value="Savings", background="#f2f3f4").place(relx=0.511, rely=0.174)
        Radiobutton(self.register, text="Current", variable=self.acc_type, value="Current", background="#f2f3f4").place(relx=0.706, rely=0.174)

        # Date of Birth
        Label(self.register, text="Birth Date (DD/MM/YYYY):", background="#f2f3f4").place(relx=0.090, rely=0.238, height=27, width=175)
        self.Entry4 = Entry(self.register, background="#cae4ff")
        self.Entry4.place(relx=0.511, rely=0.248, height=20, relwidth=0.302)

        # Mobile Number
        Label(self.register, text="Mobile Number:", background="#f2f3f4").place(relx=0.268, rely=0.323, height=22, width=85)
        self.Entry5 = Entry(self.register, background="#cae4ff")
        self.Entry5.place(relx=0.511, rely=0.323, height=20, relwidth=0.302)

        # Gender
        Label(self.register, text="Gender:", background="#f2f3f4").place(relx=0.345, rely=0.402, height=15, width=65)
        self.gender = StringVar(value="")
        Radiobutton(self.register, text="Male", variable=self.gender, value="Male", background="#f2f3f4").place(relx=0.481, rely=0.397)
        Radiobutton(self.register, text="Female", variable=self.gender, value="Female", background="#f2f3f4").place(relx=0.706, rely=0.397)

        # Nationality
        Label(self.register, text="Nationality:", background="#f2f3f4").place(relx=0.309, rely=0.471, height=21, width=75)
        self.Entry7 = Entry(self.register, background="#cae4ff")
        self.Entry7.place(relx=0.511, rely=0.471, height=20, relwidth=0.302)

        # KYC Document
        Label(self.register, text="KYC Document Name:", background="#f2f3f4").place(relx=0.18, rely=0.546, height=24, width=122)
        self.Entry8 = Entry(self.register, background="#cae4ff")
        self.Entry8.place(relx=0.511, rely=0.546, height=20, relwidth=0.302)

        # Password
        Label(self.register, text="Password:", background="#f2f3f4").place(relx=0.350, rely=0.62, height=21, width=50)
        self.Entry9 = Entry(self.register, show="*", background="#cae4ff")
        self.Entry9.place(relx=0.511, rely=0.623, height=20, relwidth=0.302)

        # Confirm Password
        Label(self.register, text="Re-enter Password:", background="#f2f3f4").place(relx=0.230, rely=0.695, height=21, width=100)
        self.Entry10 = Entry(self.register, show="*", background="#cae4ff")
        self.Entry10.place(relx=0.511, rely=0.7, height=20, relwidth=0.302)

        # Initial Balance
        Label(self.register, text="Initial Balance:", background="#f2f3f4").place(relx=0.292, rely=0.779, height=21, width=75)
        self.Entry11 = Entry(self.register, background="#cae4ff")
        self.Entry11.place(relx=0.511, rely=0.777, height=20, relwidth=0.302)

        # Buttons
        Button(self.register, text="Back", background="#004080", foreground="white", command=self.back).place(relx=0.243, rely=0.893, height=24, width=67)
        Button(self.register, text="Proceed", background="#004080", foreground="white", command=self.create_acc).place(relx=0.633, rely=0.893, height=24, width=67)

        self.register.protocol("WM_DELETE_WINDOW", self.back)

    def back(self):
        self.register.destroy()  # Close registration window
        subprocess.run(["python", "login.py"])  # Reopen login window

    def create_acc(self):
        name = self.Entry1.get()
        username = self.Entry2.get()
        account_type = self.acc_type.get()
        date_of_birth = self.Entry4.get()
        mobile_number = self.Entry5.get()
        gender = self.gender.get()
        nationality = self.Entry7.get()
        kyc_document = self.Entry8.get()
        pwd = self.Entry9.get()
        confirm_pwd = self.Entry10.get()
        initial_bal = self.Entry11.get()
        status='pending'
        usertype='user'

        dob_obj = datetime.strptime(date_of_birth, "%d/%m/%Y")
        dob = dob_obj.strftime("%Y/%m/%d")

        # Input Validations
        if not name:
            messagebox.showerror("Error", "Invalid Name!")
            return

        if not username:
            messagebox.showerror("Error", "User Name can't be empty!")
            return

        if account_type not in ["Savings", "Current"]:
            messagebox.showerror("Error", "Select an account type!")
            return

        if not self.check_date_format(date_of_birth):
            messagebox.showerror("Error", "Invalid Date of Birth format!")
            return

        if not mobile_number.isdigit() or len(mobile_number) != 10:
            messagebox.showerror("Error", "Invalid Mobile Number!")
            return

        if gender not in ["Male", "Female"]:
            messagebox.showerror("Error", "Select Gender!")
            return

        if not nationality:
            messagebox.showerror("Error", "Enter Nationality!")
            return

        if not kyc_document:
            messagebox.showerror("Error", "Enter KYC Document Name!")
            return

        if not len(pwd) >= 8:
            messagebox.showerror("Error", "PASSWORD must be 8 digits!")
            return

        if pwd != confirm_pwd:
            messagebox.showerror("Error", "Password mismatch!")
            return
        
        try:
            initial_balance = int(initial_bal)
            if not initial_balance >= 500:
                messagebox.showerror("Error", "Initial Balance amount Rs 500/- or more!")
                return
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number for the Initial Balance!")
            return

        conn = mysql.connector.connect(host="localhost", user="root", password="1234", port="3306",database="banking")
        mycursor = conn.cursor()
    
        query = "INSERT INTO useraccount (name, username, account_type, date_of_birth, mobile_number, gender, nationality, kyc_document, pwd, initial_balance, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        values = (name, username, account_type, dob, mobile_number, gender, nationality, kyc_document, pwd, initial_balance, status)
    
        query1 = "INSERT INTO login (uname, password, usertype) VALUES (%s, %s, %s)"
        values1 = (username, pwd, usertype)

        mycursor.execute(query, values)
        mycursor.execute(query1, values1)
        conn.commit()
        conn.close()
        messagebox.showinfo('Success',"Data Entered Successfully")
        self.clear_entries()

        self.register.destroy()  # Close registration window
        subprocess.run(["python", "login.py"])  # Reopen login window

    def clear_entries(self):
        self.Entry1.delete(0, END)
        self.Entry2.delete(0, END)
        self.Entry4.delete(0, END)
        self.Entry5.delete(0, END)
        self.Entry7.delete(0, END)
        self.Entry8.delete(0, END)
        self.Entry9.delete(0, END)
        self.Entry10.delete(0, END)
        self.Entry11.delete(0, END)
        self.acc_type.set("")
        self.gender.set("") 


    @staticmethod
    def check_date_format(date_str):
        try:
            datetime.strptime(date_str, "%d/%m/%Y")  # Proper date validation
            return True
        except ValueError:
            return False
        


