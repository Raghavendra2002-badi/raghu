from tkinter import *
from tkinter import messagebox
import subprocess
from windowsize import screen_size
from AdminApprove import approve
from AdminOpen_Account import open_account
from amount import account_info
from AccountReg import newaccountreg
from AdminDeposit import adm_deposit
from AdminWithdraw import withdraw
from AdminAmountTransfer import amt_transfer
from AdminBalance import balance
from AdminReport import report

class admin_window:

    def __init__(self, parent):
        self.parent=parent
        self.admindashboard()
        self.parent.title("Welcome Admin")
        p1 = PhotoImage(file='./images/bank1.png')
        self.parent.iconphoto(True, p1)
        self.parent.configure(background="#023047")

    def admindashboard(self):
        admin_win = Toplevel(self.parent)

        def exit_app():
            admin_win.destroy()
            self.parent.destroy()
            subprocess.run(["python", "login.py"])  # Reopen login window

        menu_bar=Menu(admin_win)

        account_menu=Menu(menu_bar, tearoff=0)
        account_menu.add_command(label="My Profile",)
        account_menu.add_separator()
        account_menu.add_command(label="Approve",command=lambda: approve(admin_win))
        account_menu.add_separator()
        account_menu.add_command(label="Open Account",command=lambda: newaccountreg(parent=admin_win))
        account_menu.add_separator()
        account_menu.add_command(label="Logout",command=exit_app)
        menu_bar.add_cascade(label="Account Management", menu=account_menu)

        transation_menu=Menu(menu_bar, tearoff=0)
        transation_menu.add_command(label="Deposit",command=lambda: adm_deposit(admin_win))
        transation_menu.add_separator()
        transation_menu.add_command(label="Withdraw",command=lambda: withdraw(admin_win))
        transation_menu.add_separator()
        transation_menu.add_command(label="Amount Transfer",command=lambda: amt_transfer(admin_win))
        transation_menu.add_separator()
        transation_menu.add_command(label="Balance",command=lambda: balance(admin_win))
        menu_bar.add_cascade(label="Transaction",menu=transation_menu)

        report_menu=Menu(menu_bar, tearoff=0)
        report_menu.add_command(label="Report",command=lambda: report(admin_win))
        menu_bar.add_cascade(label="Report",menu=report_menu)

        admin_win.config(menu=menu_bar)
        screen_size(admin_win)

        # Bind the close event of the admin window to reopen the login page
        admin_win.protocol("WM_DELETE_WINDOW", lambda: exit_app())