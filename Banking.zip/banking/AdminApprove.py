from tkinter import *
from tkinter import messagebox

def approve(parent):
    approve_win = Toplevel(parent)
    approve_win.title("Approve Account")
    
    menu_bar=Menu(approve_win)

    account_menu=Menu(menu_bar, tearoff=0)
    #account_menu.add_separator()
    menu_bar.add_cascade(label="New", menu=account_menu)

    approve_win.config(menu=menu_bar)
    approve_win.geometry("400x300")
