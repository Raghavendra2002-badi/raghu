import mysql.connector
from tkinter import *
from tkinter import messagebox, PhotoImage, Canvas, Label, Entry, Button
from AdminDashboard import admin_window
from UserDashboard import user_window
from NewAccountReg import newaccountreg

class login_window:

    def __init__(self, root):
        self.root = root
        self.root.title("Welcome to Banking")
        self.root.minsize(120, 1)
        self.root.maxsize(1370, 749)
        self.root.resizable(0, 0)
        p1 = PhotoImage(file='./images/bank1.png')
        self.root.iconphoto(True, p1)
        self.root.configure(background="#023047")
        self.root.configure(cursor="arrow")

        # Display window in center of the screen
        # Get screen width and height
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        # Calculate position x, y
        x = (screen_width // 2) - (500 // 2)
        y = (screen_height // 2) - (400 // 2)
        # Set geometry with calculated position
        self.root.geometry(f"500x350+{x}+{y}")

        self.Canvas1 = Canvas(self.root, background="#ffff00", borderwidth="0", insertbackground="black",
                                 relief="ridge", selectbackground="blue", selectforeground="white")
        self.Canvas1.place(x=95, y=80, height=200, width=300)

        self.Label1 = Label(self.Canvas1, background="#ffff00", disabledforeground="#a3a3a3",
                               font="-family {Segoe UI} -size 13 -weight bold", foreground="#000000",
                               text='''Welcome Login Page''')
        self.Label1.place(x=45, y=5, height=31, width=194)

        self.unamelabel=Label(self.root, background="#ffff00", disabledforeground="#a3a3a3",
                               font="-family {Segoe UI} -size 10 -weight bold", foreground="#000000", text="Username")
        self.unamelabel.place(x=130, y=130, height=31, width=80)
        self.entry1 = Entry(self.root)
        self.entry1.place(x=210, y=140)
        self.entry1.focus_set()  # Set focus on the username entry

        self.passlabel=Label(self.root, background="#ffff00", disabledforeground="#a3a3a3",
                               font="-family {Segoe UI} -size 10 -weight bold", foreground="#000000",text="Password")
        self.passlabel.place(x=130, y=170, height=31, width=80)
        self.entry2 = Entry(self.root, show='*')
        self.entry2.place(x=210, y=175)

        self.login_button = Button(self.root, text="Login", borderwidth="0", width=8,
                                foreground="#00254a", font="-family {Segoe UI} -size 10 -weight bold", 
                                command=self.login_ok)
        self.login_button.place(x=260, y=210)

        self.login_button = Button(self.root, text="New User Registration", borderwidth="0", width=20,background="#ffff00",
                                    activebackground="#ffff00", foreground="blue", activeforeground="blue", 
                                    font="-family {Segoe UI} -size 10 -weight bold", cursor="hand2", command=self.open_register_window)
        self.login_button.place(x=100, y=250)
    def open_register_window(self):
        self.root.destroy()  # Close login window
        root = Tk()
        app = newaccountreg(root)  # Open registration window
        root.mainloop()


    def login_ok(self):
        conn = mysql.connector.connect(host="localhost", user="root", password="1234", port="3306", database="banking")
        mycursor = conn.cursor()
        uname = self.entry1.get()
        password = self.entry2.get()

        sql = "select * from login where uname= %s and password= %s"
        mycursor.execute(sql, (uname, password))
        results = mycursor.fetchone()
        if results:
            usertype = results[2]
            if usertype == 'admin':
                self.root.withdraw()
                admin_window(parent=self.root)
                return True
            elif usertype == 'user':
                self.root.withdraw()
                user_window(parent=self.root)
                return True
        else:
            messagebox.showinfo("", "Incorrect Username or Password")
            return False

if __name__ == "__main__":
    root = Tk()
    app = login_window(root)
    root.mainloop()

