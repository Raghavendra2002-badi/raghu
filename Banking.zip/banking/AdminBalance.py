from tkinter import *
from tkinter import messagebox

def balance(parent):
    balance = Toplevel(parent)
    balance.title("Balance")
    
    balance.geometry("400x300")