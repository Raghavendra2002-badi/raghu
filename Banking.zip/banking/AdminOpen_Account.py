from tkinter import *
import mysql.connector
from tkinter import ttk
from tkinter import messagebox

def open_account(parent):
    approve_win = Toplevel(parent)
    approve_win.title("Open Account")
    
    approve_win.geometry("300x400")

    Label(approve_win, text="Welcome to Banking", font=("Arial",16)).place(x=50, y=5)
    Label(approve_win, text="Name").place(x=50, y=60)
    Label(approve_win, text="House Name/No").place(x=50, y=90)
    Label(approve_win, text="Post Office").place(x=50, y=120)
    Label(approve_win, text="PIN").place(x=50, y=150)
    Label(approve_win, text="District").place(x=50, y=180)
    Label(approve_win, text="State").place(x=50, y=210)
    Label(approve_win, text="Mobile No").place(x=50, y=240)
    Label(approve_win, text="Email").place(x=50, y=270)
    Label(approve_win, text="KYC").place(x=50, y=300)

    e1 = Entry(approve_win)
    e1.place(x=145, y=60)
    e1.focus_set()  # Set focus on the username entry
    e2 = Entry(approve_win)
    e2.place(x=145, y=90)
    #e2.config(show='*')
    e3 = Entry(approve_win)
    e3.place(x=145, y=120)
    e4 = Entry(approve_win)
    e4.place(x=145, y=150)
    e5 = Entry(approve_win)
    e5.place(x=145, y=180)
    e6 = Entry(approve_win)
    e6.place(x=145, y=210)
    e7 = Entry(approve_win)
    e7.place(x=145, y=240)
    e8 = Entry(approve_win)
    e8.place(x=145, y=270)
    e9 = Entry(approve_win)
    e9.place(x=145, y=300)
    e9 = Entry(approve_win)
    e9.place(x=145, y=330)

from tkinter import *
from tkinter import messagebox

def open_account(parent):
    approve_win = Toplevel(parent)
    approve_win.title("Open Account")
    
    screen_width = approve_win.winfo_screenwidth()
    screen_height = approve_win.winfo_screenheight()
    # Calculate position x, y
    x = (screen_width // 2) - (300 // 2)
    y = (screen_height // 2) - (200 // 2)
    # Set geometry with calculated position
    approve_win.geometry(f"500x500+{x}+{y}")

    Label(approve_win, text="Open New Account", font=("Arial",16)).place(x=150, y=5)
    Label(approve_win, text="First Name").place(x=50, y=60)
    Label(approve_win, text="Last Name").place(x=280, y=60)
    Label(approve_win, text="Username").place(x=50, y=90)
    Label(approve_win, text="Password").place(x=280, y=120)
    Label(approve_win, text="Reenter Password").place(x=280, y=120)
    Label(approve_win, text="House Name/No").place(x=50, y=150)
    Label(approve_win, text="Post Office").place(x=50, y=180)
    Label(approve_win, text="PIN").place(x=280, y=180)
    Label(approve_win, text="District").place(x=50, y=210)
    Label(approve_win, text="State").place(x=50, y=240)
    Label(approve_win, text="Mobile No").place(x=50, y=270)
    Label(approve_win, text="Email").place(x=50, y=300)
    Label(approve_win, text="KYC").place(x=50, y=330)
    Label(approve_win, text="KYC No").place(x=280, y=330)
    e1 = Entry(approve_win)
    e1.place(x=145, y=60)
    e1.focus_set()  # Set focus on the username entry
    e2 = Entry(approve_win)
    e2.place(x=445, y=60)
    e2 = Entry(approve_win)
    e2.place(x=145, y=90)
    #e2.config(show='*')
    e3 = Entry(approve_win)
    e3.place(x=145, y=120)
    e4 = Entry(approve_win)
    e4.place(x=145, y=150)
    e5 = Entry(approve_win)
    e5.place(x=145, y=180)
    e6 = Entry(approve_win)
    e6.place(x=145, y=210)
    e7 = Entry(approve_win)
    e7.place(x=145, y=240)
    e8 = Entry(approve_win)
    e8.place(x=145, y=270)
    e9 = Entry(approve_win)
    e9.place(x=145, y=330)

    # Create a Combobox (Dropdown)
    options = ["Aadhar", "Driving Licences", "Pan Card", "Passport", "Voter Id"]
    combo = ttk.Combobox(approve_win, values=options)
    combo.place(x=145, y=300)

    # Bind the Combobox selection event to the option_selected function
    combo.bind("<<ComboboxSelected>>", option_selected)
    
    submit_button=Button(approve_win,text="Submit", command=lambda:save_open(e1, e2, e3, e4, e5, e6, e7, e8, e9, combo), height=1, width=6,font=("Arial",14))
    submit_button.place(x=120, y=370)

# Function to be called when an option is selected
def option_selected(event):
    selected_option = event.widget.get()
    print(f"Selected option: {selected_option}")

def save_open(e1, e2, e3, e4, e5, e6, e7, e8, e9, combo):
    name=e1.get()
    house=e2.get()
    post_office=e3.get()
    pin=e4.get()
    district=e5.get()
    state=e6.get()
    mobile=e7.get()
    email=e8.get()
    kyc=combo.get()
    kyc_no=e9.get()
    conn = mysql.connector.connect(host="localhost", user="root", password="", port="3307",database="banking")
    mycursor = conn.cursor()
    
    query = "INSERT INTO account (name, house, post_office, pin, district, state, mobile, email, kyc, kyc_no) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    values = (name, house, post_office, pin, district, state, mobile, email, kyc, kyc_no)
    
    mycursor.execute(query, values)
    conn.commit()
    conn.close()
    messagebox.showinfo('Success',"Data Entered Successfully")

    clear_entries([e1, e2, e3, e4, e5, e6, e7, e8, e9])
    combo.set('') 

def clear_entries(entries):
    for entry in entries:
        entry.delete(0, END)